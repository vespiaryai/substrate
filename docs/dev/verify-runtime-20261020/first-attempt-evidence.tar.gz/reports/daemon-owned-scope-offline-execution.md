# Daemon owned-scope offline execution

20 October 2026. Task `task_d35e44d44bf4`, dispatch `ctx_e8d010585409`.
Fresh local Sol owner. The single root-granted offline command exited zero. Root acceptance remains pending.
This qualifies the selected changed-source fixtures only. No real daemon or Goal completion follows.

The frozen repository HEAD is `ba85de0b26729d288d0f44c50d133bd30724b003` before and after.
The frozen 60-line preparation and all driver-bundle bytes remain unchanged.
The only repository addition is the authorized restored refusal fixture at `hack/goal330-verify-runtime/owned-scope-offline-ctx-e8d010585409/guard-refusal.txt`.
It contains `unchanged\n`. The old historical fixture, driver, receipts, manifests, and source packets remain unchanged.

Root granted the exact command after reconciling eleven prior pending/root closure records and confirming the fixed real-daemon intent absent.
The reservation remains `reviews/daemon-owned-scope-offline-pending.json`. This worker did not modify it or write root acceptance.
The command ran exactly once with no retry.
```sh
/bin/bash /home/zack/.codex/orchestrate/vespiary-goal330/reviews/daemon-owned-scope-offline-driver-ctx-e8d010585409/proposed-command.sh
```
Driver SHA-256 remains `43a7c14c35da5ecb08e67c1ae72cd4d3b5153bad5d67a82f38c8282fa008c002`.
Command SHA-256 remains `4880c6642556a204e7ad6f0b3cf2ab5a94831d2befd3ce4a07ee66a090eea454`.
Bundle SHA-256 remains `7ccea731c3642aaff27556083a35cc7ec48232f3f1ff3b7753adae4c9bea649a`.

Both exact unittest-discover children passed. Actual verbose output records 22 daemon cases and four unchanged job-helper cases, with no skips.
Every complete actual case ID matches the frozen expected-case list. Both actual IDs and counts are retained in `raw/actual-case-ids.json`.
The historical 14-case receipt remains evidence for its old source only.
All 55 recorded commands exited zero except the expected mutation guard exit 97. The suite command and its guard exited zero.
The suite before/after maps contain 13,617 entries and are byte-identical.
Stable, mutation and restored control maps contain 13,618 entries. Their guard exits are `0, 97, 0`, with child exit zero each time.
Only the new exact refusal fixture differs in the mutation maps. Stable-before and restored-after are byte-identical.
Actual copies of all ten current manifest entries plus the manifest itself are retained in `raw/source-before` and `raw/source-after`.
All eleven before/after byte pairs equal current source and the prepared hashes. Every selected path appears unchanged in every guard map.
Full parent repository maps differ only by the restored new fixture. All frozen source, native, canonical guard, and bundle hashes remain unchanged.
The historical eight-entry source manifest was never checked against current changed helper bytes.

The exact native unit is `goal330-daemon-owned-scope-offline-ctx-e8d010585409.service` in `app.slice`.
Invocation is `07b059683edc401896d6c2fb2d43953c`. Unit PID/start ticks are `822332/2550326`.
The outside owner PID/start ticks are `822319/2550287`. Boot and exact cgroups are retained in the owner receipts.
Actual leaf controls are CPU `200000 100000`, memory `2147483648`, swap `0`, and tasks `128`.
All ancestor controls are retained. Live properties record native runtime `1min`, extra runtime `0`, stop `5s`, control-group kill, SIGKILL enabled, and no restart.
The inherited driver asserted both address-space limits as 2147483648 before tests. It did not separately save that numeric tuple.
The configured client uses a 70-second TERM deadline and two-second KILL delay. The native unit runtime is 60 seconds.
These observations establish normal completion, not deadline expiry or owner-loss behavior.

Postflight records not-found/inactive/dead, MainPID zero, empty Job and ControlGroup, and Result success.
The exact queued-job query exited zero with empty stdout and stderr. The outside owner checked exact cgroup absence and original unit extinction while holding flock.
`raw/closed.json` records unitClosed, parentLockHeld, sourceStable and driverStable true, with result zero.
`raw/unlocked.json` records unlock and close of device 54, inode 4045. `raw/release.json` records original-owner extinction and actual same-inode reacquisition and release.
Later file-only inspection found both original PID identities gone and the exact recorded cgroup absent. No global process or UID census ran.
Root must independently inspect exact unit/job/cgroup/process closure and actual release and write a distinct companion before any later heavy grant.

Raw evidence remains at `/tmp/goal330-daemon-owned-scope-offline-ctx-e8d010585409`.
A byte-verified copy of all 213 raw files is retained at `reviews/daemon-owned-scope-offline-execution-ctx-e8d010585409/raw` under this rootstore.
That directory's parent holds inspection.json, raw-sha256.json, command-result.json, the copied reservation, decisions.tsv and evidence.sha256.
The frozen preparation and proposal remain historical preparation, with their unrun wording preserved.

All thirteen preferences, Poteto Feature/Investigation, split-PR rules, orchestration, full source/review/old receipts and triggered installed leaves remain inherited.
Model the Domain retained exact case IDs. Laziness Protocol reused the native owner. Prove It Works required actual byte pairs and raw native receipts.
Sequence Work into Verifiable Units leaves root acceptance and later native work separate. Installed control-cli and no-comments were read. The driver adds no comments or suppressions.
No bootstrap, Docker API, daemon, install, sudo, Go, full make verify, product code review, commit, PR, production change or integration ran.
Fixed daemon P/R/unit/intent remain unused. A later actual bootstrap needs a separate preflight/qualification grant after root closure.
Attention. No nested worker, model call, delegated how/arena, unavailable Cursor Task/create-skill, or independent trail review ran. Root acceptance is pending.
