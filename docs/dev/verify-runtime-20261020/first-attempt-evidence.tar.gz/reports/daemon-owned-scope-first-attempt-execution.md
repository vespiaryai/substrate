# First daemon attempt failed before Info execution

20 October 2026. Task `task_d35e44d44bf4`, dispatch `ctx_e8d010585409`, grant `msg_b237e69590d0`.
The exact first-attempt command ran once and exited 1. This is a failed native qualification, not an installer failure.
Root recovery inspection and both distinct closure attestations remain required. No retry or source repair ran.

Repository HEAD remains `ba85de0b26729d288d0f44c50d133bd30724b003`.
The command was `/bin/bash /home/zack/.codex/orchestrate/vespiary-goal330/reviews/daemon-owned-scope-first-attempt-ctx-e8d010585409/proposed-command.sh`.
Root inspected the frozen full plan/scripts/argv, reconciled thirteen prior reservations and granted one 500-second normal attempt.
The active reservation is `reviews/daemon-owned-scope-first-attempt-pending.json`. This worker did not modify it.
All original preparation, source, offline evidence, restored fixtures, manifests, commands and historical failure bytes remain unchanged.
The earlier accepted 26-case offline result remains scoped to its synthetic controls and actual pre-work native test-unit bounds.

Ordinary preflight passed. It required exact fixed intent/raw/root companion and P/R absence plus native NoSuchUnit for slice, daemon and Info.
It found no exact loaded unit, queued job or unit file and verified all ten current source entries and both native manifests.
Ordinary UID/GID, parent/rootstore access, ancestry, declared host fingerprints, Enforcing SELinux and own metadata reads passed.
Own start/cgroup/mount identity was stable. No unrelated process/UID/fd scan or denied PID 3089 read occurred.
Preflight command and guard both exited zero, with 13,618 source entries and no changed path.

The helper then acquired its canonical flock and exclusively wrote the fixed pending receipt before native mutation.
The exact slice start job completed and actual parent bounds were CPU `200000 100000`, memory `4294967296`, swap `0`, and tasks `512`.
The parent invocation is `91aa0bc7db214bce9cfcb1dfd068d153` and its returned job is `/org/freedesktop/systemd1/job/5004`.
Its cgroup is `/user.slice/user-1000.slice/user@1000.service/vesverifyb7a6306f20fabfaab02a29eaecf04531.slice`.
The daemon start job completed with invocation `0475832c78c94166a89caabe14f5b1ab` and job `/org/freedesktop/systemd1/job/5007`.
Its exact cgroup is the parent's `/vesverifyb7a6306f20fabfaab02a29eaecf04531-daemon.service` child.
The helper reached private socket readiness and verified the path was a socket before requesting Info.
Keeper PID/start ticks are `839775/2670430`, on boot `a0b03e42-3394-4bbd-acee-70a20c745b4b`.
Its exact outside cgroup, argv and namespace identities remain in the fixed pending receipt.

Info StartTransientUnit raised `org.freedesktop.DBus.Error.InvalidArgs` with the following actual message.
```text
Invalid StandardOutput setting: file:/home/zack/.local/share/vesverifyb7a6306f20fabfaab02a29eaecf04531/info.json
```
The traceback identifies `daemon_bootstrap.py:568` and `systemd_job.py:54`. No successful Info job was obtained.
The fixed `.failed.json` records this DBusException and the actual helper/job/oracle source hashes as `failed-or-unknown`.
The failure occurred before Info validation, owned actor metadata, managed-containerd verification and detached-nsfs observation.
No zero-object/security Info result, normal stop job, owned-reference closure or native cleanup proof follows from this run.
The helper exception path exited. It does not stop the native services or establish their extinction.
The configured daemon runtime remains 180 seconds and stop timeout 15 seconds. Actual expiry and closure are root's gate, not this report's claim.

Bootstrap client and canonical guard exited 1 with 13,618 unchanged source entries.
Both preflight and bootstrap before/after guard maps are byte-identical. No changed input invalidates or explains away this actual failure.
Full before/after maps contain 13,695 repository, native and bundle paths and match exactly.
All 13,019 referenced content-addressed blobs pass digest verification. Frozen source/native/bundle input manifests still match actual files.
`attempt-result.json` records bootstrapLaunched true, commandExit 1, sourceStable true, retryAllowed false, and rootAcceptance pending.
The full exact command argv, finite waits, stdout/stderr and source maps remain retained.
Post-native host fingerprint equality, terminal unit/job state, socket absence, aggregate cgroup emptiness and all original PID extinction are unproved here.
An available flock, dead keeper, client exit or absent API cannot substitute for those facts.

The fixed pending, parent, daemon and failed companions remain at their exact original rootstore paths.
Byte-verified copies and hashes are under `reviews/daemon-owned-scope-first-attempt-ctx-e8d010585409/fixed-receipts`.
At capture, fixed `.observation.json`, `.stopped.json` and `.closed.json` were absent. No raw closed companion was invented.
The P/R data and runtime trees remain untouched by this worker after failure. No cleanup, unlink, stop, prune, alternate observer or privilege ran.
The complete external evidence directory contains 13,059 files covered by execution-evidence.sha256, plus that manifest itself.
`inspection.json` retains the byte comparisons, fixed hashes, missing-companion truth and explicit root-recovery requirement.
Immediate escalation `msg_e7772fa4a3ac` reported this failure and exact identities before archive completion.
Root must independently inspect/reconcile the exact native set and actual release of the same canonical inode recorded by preflight.
Both the coordinator companion and `daemon-only-root-closed-b7a6306f20fabfaab02a29eaecf04531.json` are required before another heavy grant.

All thirteen preferences and mandatory installed Poteto/split-PR rules remain inherited. No repository/index/ref change or nested worker/model call ran.
Model the Domain retained literal argv and failure records. Boundary Discipline preserved the native rejection. Prove It Works retained actual failed bytes.
Sequence Work into Verifiable Units stops qualification at this failure and leaves recovery, any repair and any later grant with root.
Go/product review, full make verify, installer, image/container operations, production, commit, PR and integration remain outside this run.
Attention. Native qualification failed. Root closure and independent trail review remain pending, and no unavailable Cursor Task/create-skill or broader proof is claimed.
