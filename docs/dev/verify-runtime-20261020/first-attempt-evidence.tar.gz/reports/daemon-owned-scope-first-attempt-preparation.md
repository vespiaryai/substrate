# First owned-scope daemon attempt preparation

20 October 2026. Task `task_d35e44d44bf4`, dispatch `ctx_e8d010585409`, continuing under `msg_7db96725a133`.
Fresh local Sol retains the costly checkout at `ba85de0b26729d288d0f44c50d133bd30724b003`.
This new phase is source-only. No prepared preflight, helper import, syntax check, bootstrap, native unit or API has run.
Root independently accepted the 26-case offline batch in `reviews/daemon-owned-scope-offline-closed.json`.
The original preparation, offline driver/evidence, historical failure, source packets, native manifests, repository and two restored fixtures remain unchanged.

The new bundle is `reviews/daemon-owned-scope-first-attempt-ctx-e8d010585409` under this rootstore.
The proposed literal entry command is UNRUN.
```sh
/bin/bash /home/zack/.codex/orchestrate/vespiary-goal330/reviews/daemon-owned-scope-first-attempt-ctx-e8d010585409/proposed-command.sh
```
`proposed-argv.json` contains the complete literal argv for the preflight and conditional bootstrap. The finite serial launcher consumes that table.
The bootstrap child remains byte-identical to the earlier proposed daemon command and invokes the current reviewed helper from this exact checkout.
No resource framework, supervisor, daemon source repair, new nonce, privileged observer, or recovery daemon was added.

Ordinary preflight requires exact fixed P/R absence, no intent or raw/root companion, no exact unit/job/unit file, and native NoSuchUnit for all three units.
It checks UID/GID 1000, ancestry without symlinks, ordinary parent/rootstore access, exact current HEAD, ten source entries and both unchanged native manifests.
It retains declared host fingerprint reads, Enforcing SELinux, and the canonical lock's stat identity without acquiring flock.
It reads only its own namespace links, process metadata, mounts and fd-link metadata, with its own start ticks, cgroup and mounts checked before and after.
The obsolete same-UID scan and denied PID 3089 read are absent. Outside holders remain unmeasured.
The native child/daemon actors do not yet exist during preflight. Their future ordinary metadata access remains unproved.
A denial or first-use refusal exits before bootstrap. No sudo, alternative access, changed host security, or silent skip follows.

Preflight has its original 60-second native alarm, a 75-second TERM client, two-second KILL delay, and finite 80-second parent wait.
Only successful preflight plus stable guard maps and unchanged frozen inputs permits the one helper launch.
The helper retains its 300-second default native alarm and actual canonical nonblocking flock ownership.
Bootstrap has a 330-second TERM client, two-second KILL delay, and finite 335-second parent wait.
Before/after source snapshots each have a 30-second parent wait. The configured child waits total 475 seconds, excluding small serial file operations.
The snapshotter retains actual content-addressed bytes for repository application/config/oracles, selected native inputs, guard and all proposal inputs.
Both commands use the unchanged f98 canonical guard. Each guard's before/after maps must match byte for byte.
After-snapshot byte maps must equal before-snapshot maps. Changed inputs preserve original receipts and fail the batch, even if a loaded child exits zero.
No retry exists. First-use output writes are exclusive. Failed or missing final snapshots preserve uncertainty for root.

The real helper still creates the exact fixed private paths and durable fixed pending receipt before native mutation.
The daemon slice retains two CPUs, 4 GiB, zero swap and 512 tasks, checked before daemon birth.
The daemon remains Type=exec in that exact slice, runtime 180 seconds, stop 15 seconds, no restart, and managed private containerd.
Info remains the explicit private zero-image/zero-container request, followed by exact owned jobs and finite normal teardown.
The accepted offline unit recorded native two-CPU/2-GiB/zero-swap/128-task controls before guard and unittest child work.
That proves this installed native service's pre-work bounds and ordinary fork/exec inheritance contract for its children.
It does not prove this fixed daemon slice's 4-GiB/512-task controls, daemon-specific pre-work behavior, or real detached-nsfs observations.
The real attempt must bind its pre-birth parent controls, native placement contract, exact invocation/cgroup and owned PID/start identities.
Actual deliberately weakened native bounds, keeper loss, expiry and recovery remain separate unproved gates.

Any essential owned metadata denial stops the attempt and retains fixed intent/failure plus the recorded native unit/cgroup identities for root reconciliation.
The helper's exception/alarm path can exit and release flock while native actors remain. The launcher adds no automatic cleanup or retry.
Even normal client exit requires root inspection of successful jobs, terminal exact units, empty/absent owned cgroup, original PID extinction, absent sockets and owned-reference closure.
Outside namespace acquisition remains explicitly assumed absent. This cannot prove universal namespace absence or malicious same-UID isolation.
Root must independently prove actual release of the same canonical inode recorded by preflight and write the distinct fixed root companion.
A raw closed receipt, client zero, source stability, available flock, dead keeper, or absent API never authorizes later heavy work alone.

The current ten-entry source manifest remains `e49e02e816ca35c9f4b152a33e56aa1c4119e8dae47213ccebccd5b82b31bea8`.
Historical eight-entry `daemon-only.sha256` checks belong only against the retained BEFORE packet, never changed current helper bytes.
Preflight SHA-256 is `1f5c909f39591fc77a1b1895a338c5ce559ebf975aa6f1aaa227c4b71c8f554e`.
Launcher SHA-256 is `1eba7f0aa4e0a82198b7d73aa4dcb8bfc3502c31bf5259b6aa9227f013ad55f9`.
Entry-command SHA-256 is `2eac7923d12cf7538cf20937b4805ebd68ed1fe00ea9151f45c207e135d8a59e`.
Literal-argv SHA-256 is `4006fcca11b86e006e1c3ef51e93e776dd4f45393919223dd8165c75349b3b36`.
Expected-inputs SHA-256 is `1d04e0da61361a516af7391bfdfcdbf949a10c82e3ef0698d0693acd854c7853` and binds 78 source/native paths.
Driver-native SHA-256 remains `2a9297b992ac7588e256aed345aff8e80f1187c8428199d73824be5d8d0cf234`. Canonical guard remains f98fc81cd69683177d44492150f68eec36bef531fe496a5bcd5cdc90979a9296.
Bundle-manifest SHA-256 is `e7e711f0dbb0f6ba9847d4122ae21f5526c79b38f48e6a901f3639f94cdd4ea6`.

Root must reconcile every pending/root companion again before ONE reserved first-attempt grant, including fixed intent/companions if present.
No current grant permits this command. The task stays active awaiting root's exact decision.
Go certificate/product work, full make verify, installer, zero-swap probe, images, containers, production, commit, PR and integration remain excluded.
All thirteen orders, mandatory installed Poteto Feature/Investigation, split-PR rules and triggered leaves remain inherited. `checklist.md` records the throughput checkpoint and deferred steps.
Model the Domain chose the literal argv table. Laziness Protocol retained the helper. Boundary Discipline preserves denial. Prove It Works separates offline controls from native proof.
Sequence Work into Verifiable Units keeps preparation, first attempt, root closure and future qualification separate.
Attention. No nested worker/model call, unavailable Cursor Task/create-skill, delegated how/arena, independent trail review, or native qualification is claimed.
