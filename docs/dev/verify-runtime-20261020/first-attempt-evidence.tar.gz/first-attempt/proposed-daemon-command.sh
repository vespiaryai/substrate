#!/bin/bash
exec /usr/bin/env -i PATH=/usr/bin:/bin HOME=/home/zack DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 hack/goal330-verify-runtime/daemon_bootstrap.py
