import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

evidence = Path(__file__).parent
stage = sys.argv[1]
os.umask(0o077)
blobs = evidence / 'blobs'
blobs.mkdir(exist_ok=True)
names = subprocess.check_output(['/usr/bin/git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard']).decode().split('\0')
paths = {str(Path(name).absolute()) for name in names if name}
for manifest in ('daemon-owned-scope.sha256', 'daemon-only-native.sha256', 'daemon-only-mock-native.sha256'):
    p = Path('docs/dev/verify-runtime-20261020') / manifest
    paths.add(str(p.absolute()))
    for line in p.read_text().splitlines():
        paths.add(str(Path(line.split('  ', 1)[1]).absolute()))
for line in (evidence / 'expected-inputs.sha256').read_text().splitlines():
    paths.add(line.split('  ', 1)[1])
paths.update(str(evidence / name) for name in ('preflight.py', 'snapshot.py', 'run-attempt.py',
    'proposed-command.sh', 'proposed-daemon-command.sh', 'driver-native.sha256',
    'expected-inputs.sha256', 'bundle.sha256', 'checklist.md', 'proposed-argv.json'))
rows = {}
for name in sorted(paths):
    p = Path(name)
    if not p.is_file():
        rows[name] = None
        continue
    content = p.read_bytes()
    digest = hashlib.sha256(content).hexdigest()
    blob = blobs / digest
    if not blob.exists():
        with blob.open('xb') as output:
            output.write(content)
    rows[name] = {'sha256': digest, 'bytes': len(content), 'mode': p.stat().st_mode}
with (evidence / (stage + '-bytes.json')).open('x') as output:
    json.dump(rows, output, indent=2, sort_keys=True)
    output.write('\n')
print(json.dumps({'stage': stage, 'files': len(rows), 'head': subprocess.check_output(['/usr/bin/git', 'rev-parse', 'HEAD']).decode().strip(), 'status': subprocess.check_output(['/usr/bin/git', 'status', '--short']).decode()}))
