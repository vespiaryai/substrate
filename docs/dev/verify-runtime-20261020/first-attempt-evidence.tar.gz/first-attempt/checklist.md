### Feature

**You own the design. Plan, review, verify.** Delegate implementation. Stay in the lead.

1. `how` over the affected subsystem.
2. `architect` for parallel design exploration.
3. Write the throughput checkpoint as four todo items. A dimension that genuinely does not apply (single file, no fan-out) keeps its item with `n/a: <reason>` rather than being dropped:
   - **Blocking first steps.** Gates run before fan-out.
   - **Independent workstreams.** Disjoint files, services, or layers parallelize. Shared writes serialize.
   - **Shared mutable state.** Default to splitting the target (the **separate-before-serializing-shared-state** principle skill). Serialize only for real invariants.
   - **Smallest safe decomposition.** If one worker is best, name why.
4. Delegate code-writing to a subagent using your configured feature model (default `grok-4.7-xhigh-fast`) with a specific scope (file paths, named data shape and its organizing structure per **principle-model-the-domain**, a state machine over scattered booleans, a table/registry over branching, a typed model over repeated shape assumptions, chosen before the delegate writes logic, and success criteria). When the implementation admits multiple valid shapes (error handling, abstraction layer, test structure), delegate via the **arena** skill instead so the runners surface the alternatives and the cross-judge guards the pick. Mandatory: no skip-with-reason escape, and Laziness Protocol does not override it (the gain is review separation, not lines saved). A subagent forbidden to spawn satisfies this by owning the diff directly with the same review separation. No "standing by" reply that waits on a nested agent. Comments per **Comments**. Surgical edits, re-ground against the source for upstream-derived files. Port shared-primitive improvements to all consumers and verify each. Commit liberally.
5. Verify on the matching surface. "Inconclusive" or wrong-surface is not a pass. Flag it.
6. Rebase into small, ordered commits. Stack follow-ups.
   Use the **sequence-verifiable-units** principle skill, building, verifying, and committing each small unit before the next.
7. If the design is contested, `interrogate` before shipping.
8. Run **Opening a PR**.

Code-coupled work (one feature, one migration) goes to a single owner with the checkpoint inline. That owner fans out internally after the blocking phase. Parent-level fan-out is for slices that produce independent artifacts (audits, cross-subsystem investigations, competing experiments). Rewrite the checkpoint at phase boundaries. Spawn a fresh owner rather than chaining interrupts.

**Reply:** what you built, what you chose and why, the throughput checkpoint, open decisions. Tables for design alternatives.

## Source-only first-attempt preparation

1. Done by direct tracing of the current helper, qualified offline driver, old preflight, source snapshotter, raw denial, and root companion.
2. Skip: root mandates current reviewed helper and ordinary preflight. Nested workers and model calls are forbidden.
3. Blocking first steps. Root's independent acceptance of all 26 offline cases precedes this phase. New runtime work waits for its own frozen grant.
   Independent workstreams. n/a because one retained costly checkout owns the frozen source and no nested worker is authorized.
   Shared mutable state. One new external bundle owns proposal inputs and future outputs. Root alone writes pending reservations and closure acceptance.
   Smallest safe decomposition. Reuse the old preflight and byte snapshotter. One finite serial launcher conditionally invokes the unchanged helper once.
4. Done directly under Feature's no-nested-worker exception. The data shape is a frozen literal preflight/bootstrap argv table and the existing preflight result dictionary.
5. Pending. No prepared preflight, syntax/import check, bootstrap, unit, API, installer, or daemon operation has run in this phase.
6. Skip: no commit, PR, rebase or integration is authorized.
7. Skip: no shipping. Root owns independent review and any future grant.
8. Skip: split-PR rules are read, but root owns publication.

Model the Domain places the two granted commands in proposed-argv.json. The finite launcher consumes those literal argv values.
Laziness Protocol keeps the current reviewed helper and old snapshotter. Boundary Discipline preserves essential metadata denials.
Prove It Works separates the actual accepted offline native pre-work controls from unproved daemon-specific controls and namespace behavior.
Sequence Work into Verifiable Units keeps this source proposal, a granted first attempt, root closure and every later qualification separate.
No unavailable Cursor Task or create-skill, parallel how/arena, or independent trail review is claimed.
