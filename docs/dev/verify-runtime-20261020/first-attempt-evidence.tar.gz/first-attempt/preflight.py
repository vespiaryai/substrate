import errno
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import time

import dbus

os.umask(0o077)
signal.signal(signal.SIGALRM, signal.SIG_DFL)
signal.alarm(60)
evidence = Path(__file__).parent
rootstore = evidence.parent
nonce = 'b7a6306f20fabfaab02a29eaecf04531'
private = [Path('/home/zack/.local/share/vesverify' + nonce), Path('/run/user/1000/vesverify' + nonce)]
intent = rootstore / ('daemon-only-pending-' + nonce + '.json')
units = ['vesverify' + nonce + suffix for suffix in ('.slice', '-daemon.service', '-info.service')]
checks = []
operation = 'initial'
subject = ''
started = time.time()
result = {'kind': 'preflight', 'bootstrapExecuted': False, 'mutations': [], 'checks': checks, 'startedUnix': started}
try:
    operation = 'source-head'
    head = subprocess.check_output(['/usr/bin/git', 'rev-parse', 'HEAD']).decode().strip()
    if head != 'ba85de0b26729d288d0f44c50d133bd30724b003':
        raise RuntimeError('source HEAD mismatch')
    checks.append({'check': operation, 'head': head})
    for name in ('daemon-owned-scope.sha256', 'daemon-only-native.sha256', 'daemon-only-mock-native.sha256'):
        operation = 'manifest'
        subject = name
        manifest = Path('docs/dev/verify-runtime-20261020') / name
        entries = []
        for line in manifest.read_text().splitlines():
            expected, source = line.split('  ', 1)
            subject = source
            actual = hashlib.sha256(Path(source).read_bytes()).hexdigest()
            if actual != expected:
                raise RuntimeError('source/native manifest mismatch')
            entries.append({'path': source, 'sha256': actual})
        checks.append({'check': 'manifest', 'manifest': name, 'entries': entries})
    operation = 'ordinary-user'
    if (os.getuid(), os.getgid()) != (1000, 1000):
        raise RuntimeError('unexpected ordinary user')
    checks.append({'check': operation, 'uid': os.getuid(), 'gid': os.getgid(), 'groups': os.getgroups()})
    operation = 'first-use-fixed-intent-and-companions'
    names = [p.name for p in rootstore.iterdir() if p.name.startswith(intent.stem + '.') or p.name == intent.name or p.name == ('daemon-only-root-closed-' + nonce + '.json')]
    if names:
        raise RuntimeError('fixed intent or companion already exists')
    checks.append({'check': operation, 'existing': names})
    operation = 'private-path-first-use'
    for p in private:
        subject = str(p)
        try:
            p.lstat()
        except FileNotFoundError:
            pass
        else:
            raise RuntimeError('fixed private path already exists')
        for parent in p.parents:
            metadata = parent.lstat()
            if stat.S_ISLNK(metadata.st_mode):
                raise RuntimeError('private ancestry is symlink')
        checks.append({'check': operation, 'path': str(p), 'absent': True, 'parentWritable': os.access(p.parent, os.W_OK | os.X_OK, effective_ids=True)})
        if not os.access(p.parent, os.W_OK | os.X_OK, effective_ids=True):
            raise PermissionError(errno.EACCES, 'private parent is not writable', str(p.parent))
    operation = 'rootstore-access'
    subject = str(rootstore)
    if not os.access(rootstore, os.R_OK | os.W_OK | os.X_OK, effective_ids=True):
        raise PermissionError(errno.EACCES, 'rootstore access unavailable', subject)
    lock = Path('/tmp/vespiary-heavy-validation.lock').stat()
    checks.append({'check': operation, 'lockDevice': lock.st_dev, 'lockInode': lock.st_ino, 'lockAcquired': False})
    operation = 'read-only-native-first-use'
    subject = 'exact slice daemon Info units and jobs'
    bus = dbus.bus.BusConnection('unix:path=/run/user/1000/bus')
    try:
        manager = dbus.Interface(bus.get_object('org.freedesktop.systemd1', '/org/freedesktop/systemd1'), 'org.freedesktop.systemd1.Manager')
        loaded = [str(row[0]) for row in manager.ListUnits(timeout=5) if str(row[0]) in units]
        jobs = [list(row) for row in manager.ListJobs(timeout=5) if str(row[1]) in units]
        files = [list(row) for row in manager.ListUnitFiles(timeout=5) if Path(str(row[0])).name in units]
        if loaded or jobs or files:
            raise RuntimeError('exact native unit or job is already used')
        absent = []
        for unit in units:
            try:
                manager.GetUnit(unit, timeout=5)
            except dbus.DBusException as error:
                if error.get_dbus_name() != 'org.freedesktop.systemd1.NoSuchUnit':
                    raise
                absent.append({'unit': unit, 'error': error.get_dbus_name()})
            else:
                raise RuntimeError('exact native unit is already loaded')
        checks.append({'check': operation, 'loaded': loaded, 'jobs': jobs, 'unitFiles': files, 'exactGetUnit': absent})
    finally:
        bus.close()
    operation = 'declared-host-fingerprint-reads'
    subject = '/sys/fs/selinux/enforce'
    enforce = Path(subject).read_text().strip()
    if enforce != '1':
        raise RuntimeError('SELinux is not enforcing')
    host = {'enforce': enforce, 'runLabel': os.getxattr('/run', 'security.selinux').hex(), 'files': {}, 'listeners': {}}
    for source in ('/proc/sys/net/ipv4/ip_forward', '/proc/sys/net/ipv6/conf/all/forwarding', '/etc/subuid', '/etc/subgid', '/etc/docker/daemon.json', '/usr/lib/systemd/system/docker.service', '/usr/lib/systemd/user/docker.service'):
        subject = source
        try:
            Path(source).lstat()
        except FileNotFoundError:
            host['files'][source] = None
        else:
            host['files'][source] = hashlib.sha256(Path(source).read_bytes()).hexdigest()
    for name in ('tcp', 'tcp6'):
        subject = '/proc/self/net/' + name
        host['listeners'][name] = sorted(row.split()[1] for row in Path(subject).read_text().splitlines()[1:] if row.split()[3] == '0A')
    checks.append({'check': operation, 'host': host})
    operation = 'keeper-metadata-reads'
    baseline = {name: os.readlink('/proc/self/ns/' + name) for name in ('mnt', 'net', 'user')}
    own = Path('/proc/self')
    for name in ('stat', 'cgroup', 'cmdline', 'status', 'uid_map', 'gid_map', 'attr/current', 'mountinfo'):
        subject = '/proc/self/' + name
        (own / name).read_bytes()
    checks.append({'check': operation, 'namespaces': baseline, 'boot': Path('/proc/sys/kernel/random/boot_id').read_text().strip()})
    operation = 'keeper-own-metadata-only'
    subject = '/proc/self'
    own_stat_before = (own / 'stat').read_text().rsplit(')', 1)[1].split()[19]
    own_group_before = (own / 'cgroup').read_text()
    mounts_before = (own / 'mountinfo').read_bytes()
    count = 0
    with os.scandir(own / 'fd') as descriptors:
        for entry in descriptors:
            subject = '/proc/self/fd/' + entry.name
            os.readlink(entry.path)
            count += 1
    if ((own / 'stat').read_text().rsplit(')', 1)[1].split()[19] != own_stat_before
            or (own / 'cgroup').read_text() != own_group_before
            or (own / 'mountinfo').read_bytes() != mounts_before):
        raise RuntimeError('preflight observer identity or mounts changed')
    checks.append({'check': operation, 'pid': os.getpid(), 'starttime': int(own_stat_before),
                   'cgroup': own_group_before.strip(), 'ownFdLinksRead': count,
                   'mountinfoSHA256': hashlib.sha256(mounts_before).hexdigest(),
                   'outsideHolders': 'unmeasured', 'futureOwnedActorAccess': 'unproved'})
    result['status'] = 'passed'
except BaseException as error:
    result['status'] = 'denied' if isinstance(error, PermissionError) else 'refused-or-unknown'
    result['failure'] = {'operation': operation, 'subject': subject, 'type': type(error).__name__, 'errno': getattr(error, 'errno', None), 'strerror': getattr(error, 'strerror', None)}
    if isinstance(error, dbus.DBusException):
        result['failure']['dbusName'] = error.get_dbus_name()
    if isinstance(error, RuntimeError):
        result['failure']['message'] = str(error)
finally:
    result['finishedUnix'] = time.time()
    with (evidence / 'preflight.json').open('x') as output:
        json.dump(result, output, indent=2, sort_keys=True)
        output.write('\n')
    print(json.dumps({'status': result['status'], 'failure': result.get('failure'), 'bootstrapExecuted': False}))
    signal.alarm(0)
raise SystemExit(0 if result['status'] == 'passed' else 1)
