#!/bin/bash
set -eu
cd /home/zack/orca/workspaces/substrate-goal330-20261020/goal330-daemon-only-bootstrap
exec /usr/bin/python3 -I -B /home/zack/.codex/orchestrate/vespiary-goal330/reviews/daemon-fresh-identity-native-ctx-e80eaa86a2f9/run-attempt.py
