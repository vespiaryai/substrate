import hashlib
import json
import os
from pathlib import Path
import subprocess


os.umask(0o077)
evidence = Path(__file__).parent
repo = Path('/home/zack/orca/workspaces/substrate-goal330-20261020/goal330-daemon-only-bootstrap')
clean = {'PATH': '/usr/bin:/bin', 'HOME': '/home/zack',
         'DBUS_SESSION_BUS_ADDRESS': 'unix:path=/run/user/1000/bus',
         'PYTHONDONTWRITEBYTECODE': '1'}
os.chdir(repo)
proposal = json.loads((evidence / 'proposed-argv.json').read_text())


def save(name, value):
    with (evidence / name).open('x') as output:
        json.dump(value, output, indent=2, sort_keys=True)
        output.write('\n')
        output.flush()
        os.fsync(output.fileno())


def frozen_inputs():
    for manifest in ('expected-inputs.sha256', 'bundle.sha256'):
        for line in (evidence / manifest).read_text().splitlines():
            expected, name = line.split('  ', 1)
            if hashlib.sha256(Path(name).read_bytes()).hexdigest() != expected:
                raise RuntimeError('frozen input changed: ' + name)


def call(name, argv, seconds):
    with (evidence / (name + '.stdout')).open('xb') as output, (evidence / (name + '.stderr')).open('xb') as error:
        try:
            result = subprocess.run(argv, env=clean, stdout=output, stderr=error,
                                    close_fds=True, timeout=seconds)
            code = result.returncode
        except subprocess.TimeoutExpired:
            code = 124
    save(name + '-command.json', {'argv': argv, 'cwd': str(repo), 'environment': clean,
                                 'returncode': code, 'waitSeconds': seconds})
    return code


def guarded(name):
    code = call(name, proposal[name]['argv'], proposal[name]['waitSeconds'])
    if code != 0:
        raise RuntimeError(name + ' client failed with exit ' + str(code))
    receipt = json.loads((evidence / (name + '-guard.guard.json')).read_text())
    if receipt['command_exit'] != 0 or receipt['stable'] is not True or receipt['changed']:
        raise RuntimeError(name + ' source guard refused')
    if (evidence / (name + '-guard.before.json')).read_bytes() != (evidence / (name + '-guard.after.json')).read_bytes():
        raise RuntimeError(name + ' source maps differ')


bootstrap_launched = False
source_stable = False
code = 1
try:
    save('attempt-start.json', {'bootstrapLaunched': False, 'source': 'a8fb2dadb9aa857471d96778009c868aa42a5c2f'})
    frozen_inputs()
    if call('before-snapshot', ['/usr/bin/python3', '-I', '-B', str(evidence / 'snapshot.py'), 'before'], 30) != 0:
        raise RuntimeError('before source snapshot failed')
    guarded('preflight')
    if json.loads((evidence / 'preflight.json').read_text())['status'] != 'passed':
        raise RuntimeError('preflight did not pass')
    frozen_inputs()
    bootstrap_launched = True
    save('bootstrap-launch.json', {'bootstrapLaunched': True, 'retryAllowed': False})
    guarded('bootstrap')
    code = 0
except BaseException as error:
    save('attempt-error.json', {'error': repr(error), 'bootstrapLaunched': bootstrap_launched,
                              'rootReconciliationRequired': True, 'retryAllowed': False})
finally:
    try:
        if call('after-snapshot', ['/usr/bin/python3', '-I', '-B', str(evidence / 'snapshot.py'), 'after'], 30) != 0:
            raise RuntimeError('after source snapshot failed')
        before = json.loads((evidence / 'before-bytes.json').read_text())
        after = json.loads((evidence / 'after-bytes.json').read_text())
        source_stable = before == after
        if not source_stable:
            raise RuntimeError('actual frozen source/native/bundle bytes changed')
        frozen_inputs()
    except BaseException as error:
        code = 1
        save('after-inspection-error.json', {'error': repr(error), 'rootReconciliationRequired': True})
    save('attempt-result.json', {'commandExit': code, 'bootstrapLaunched': bootstrap_launched,
                                 'sourceStable': source_stable, 'rootAcceptance': 'pending',
                                 'retryAllowed': False})
raise SystemExit(code)
