# Fresh identity native preparation

Task task_4875bcacca20, dispatch ctx_e80eaa86a2f9. Source preparation only.
Nonce `18ec13b3d43234b8ab4f79fbc49e0c1d` was generated once and recorded in `daemon-fresh-identity-source-preparation-ctx-e80eaa86a2f9/nonce-source-preparation.json`.
Actual source commit is `a8fb2dadb9aa857471d96778009c868aa42a5c2f`, pushed on `vespiary-ai/goal330-daemon-only-bootstrap`.
Base is `2bdf4d3cf253e7cdd534b796e392f2046949096d`, with reviewed Info fix `4a80b72c48069d60ac9ecd351751474caecba1e1`.
Helper SHA-256 is `65aef1d256801a185b6e14803d6afe62499630b8fb1c81f7d08c46318d6ba554`.
Only helper NONCE changed. BASE `de861e9585cc3bc92fb0d87c0da37dee4ca765a2` remains historical diagnostic provenance.
Current fourteen-entry manifest is `docs/dev/verify-runtime-20261020/daemon-fresh-identity.sha256`.
Manifest SHA-256 is `4ac5f3d4869745a0d7f423fcad2a9d9b29e57ea514601ed220082647e0c0e18f`.
The manifest covers current helper/tests/job/proposals, unchanged original coverage and old native/source manifests.
Old manifests retain historical meaning and are never applied as current helper acceptance.

All review paths below are under `/home/zack/.codex/orchestrate/vespiary-goal330/reviews`.
Offline adaptation is `daemon-fresh-identity-offline-driver-ctx-e80eaa86a2f9`.
Native adaptation is `daemon-fresh-identity-native-ctx-e80eaa86a2f9`.
Source record is `daemon-fresh-identity-source-preparation-ctx-e80eaa86a2f9`.
Static byte checks matched eleven manifests and all 13072 old bundle files. Declared host/API fingerprints matched; SELinux enforce was 1.
Original P/R trees, consumed identity, failed unit record, receipts, fixture trees and old bundles remain untouched.
Filesystem metadata found fresh P/R, fixed intent/root companion, offline output and refusal fixture absent.
P is `/home/zack/.local/share/vesverify18ec13b3d43234b8ab4f79fbc49e0c1d`.
R is `/run/user/1000/vesverify18ec13b3d43234b8ab4f79fbc49e0c1d`.
Units derive `vesverify18ec13b3d43234b8ab4f79fbc49e0c1d` plus `.slice`, `-daemon.service` and `-info.service`.
Fixed intent is `daemon-only-pending-18ec13b3d43234b8ab4f79fbc49e0c1d.json`; no intent or private path was created.
Root msg_fe61b6342235 granted exact ordinary read-only queries. All four fresh names had no listed unit, file or job; GetUnit reported not loaded.
Exact query argv/status/raw metadata is in source record first-use-native-queries.json. No reservation or future freshness follows; preflight must repeat.
Canonical lock stat remained device 54, inode 4045. It was never acquired. This is no closure or reservation claim.

The proposed offline command is UNRUN.
`/bin/bash /home/zack/.codex/orchestrate/vespiary-goal330/reviews/daemon-fresh-identity-offline-driver-ctx-e80eaa86a2f9/proposed-command.sh`
Its owner/unit/release design is copied from accepted ctx_913464a561fe; adaptation.diff shows only fresh identities and source manifest.
Exact 24 daemon and four job unittest child commands, all 28 case IDs and guard controls 0/97/0 remain unchanged.
Native bounds remain two CPUs, 2 GiB, zero swap and 128 tasks, runtime 60 and stop 5 seconds, client 70+2, parent wait 73 and normal owner 90 seconds.
Output is `/tmp/goal330-daemon-fresh-offline-ctx-e80eaa86a2f9`; native unit is `goal330-daemon-fresh-offline-ctx-e80eaa86a2f9.service`.
Refusal fixture is `hack/goal330-verify-runtime/fresh-offline-ctx-e80eaa86a2f9/guard-refusal.txt`.
Owner retains the canonical lock outside the native unit; no source/oracle may change during execution.
Root must review actual maps, thirteen byte pairs, raw/native/PID/group/cgroup closure and same-inode lock observations.
Prior 28 cases at 4a80b72 with 0/97/0, 250 archive members, 13625 paths, 64 active samples and 78 refusals remain OFFLINE ONLY.
New source invalidates that source acceptance; no current tests, imports, syntax checks, native unit or flock execution ran.

The proposed native command is UNRUN and requires a later separate root grant.
`/bin/bash /home/zack/.codex/orchestrate/vespiary-goal330/reviews/daemon-fresh-identity-native-ctx-e80eaa86a2f9/proposed-command.sh`
Its exact literal child argv is frozen in proposed-argv.json. Adaptation retains 159-line preflight, 93-line launcher and 41-line snapshot.
All original 78 expected inputs remain covered after source-manifest replacement, with five additional current source paths for 83 total.
Preflight retains alarm 60, client 75+2 and wait 80; bootstrap alarm 300, client 330+2 and wait 335; snapshots 30 each and normal 500 seconds.
The native parent retains two CPUs, 4 GiB, zero swap and 512 tasks BEFORE daemon birth.
Daemon remains Type exec, Delegate, no restart, runtime 180 and stop 15 seconds. Info remains oneshot with distinct native file setters.
No alternate PID scan, unrelated descriptor traversal, new supervisor, privilege, host change or actual mutation was added.
First-attempt original b7a6306f20fabfaab02a29eaecf04531 remains consumed forever; root job 5095 recovered the slice after daemon expiry.
Native Info, output opening, actual jobs/security/managed containerd/nsfs, normal teardown and keeper loss remain unproved.
Outside namespace holders remain unmeasured under the explicit assumption that no external actor acquires a namespace reference.
Every actual attempt requires its primary fixed intent, sidecars, distinct root companion and coordinator closure.
Root must reconcile all *-pending.json and every primary daemon-only-pending-<nonce>.json, including b7 and this nonce, before later heavy work.
Free flock, keeper exit, raw helper closed and absent API never suffice. No retry follows an unknown outcome or denial.
Unknown outcome escalates exact unit, invocation, job, cgroup, PID start and socket identities and preserves all trees and receipts.

Offline `qualify.py` SHA-256 `34f529218f323ea111aa2c5a3d998ffb3d2fd74f151895c5baa01670d4958bea`.
Offline `proposed-command.sh` SHA-256 `7fe62576fa17e4b558d0460f61427aa916779f6c354326bfcc785ce1030e1e9b`.
Offline `bundle.sha256` SHA-256 `1b9f80da1fb7c87cca2051abf0f0e39b320c155b68819af4830b56b06c691aa5`.
Offline `source.sha256` SHA-256 `45f89986d991f72a5fdf71ae099906a8a29a6b0c02f03cb5e993877bd0f345fa`.
Offline `driver-native.sha256` SHA-256 `2a9297b992ac7588e256aed345aff8e80f1187c8428199d73824be5d8d0cf234`.
Offline `expected-case-ids.json` SHA-256 `bb566ec70b6a226b114b41f4b74e8cca95e053749c59125295a2b0e4bb439f36`.
Native `preflight.py` SHA-256 `b42825cd52fb155d93b2f7f1446134906b8cb63fbd62d6f16bf180f78ad2a5f6`.
Native `run-attempt.py` SHA-256 `7446e7a027dfee14be2d01c1f27ce7c6d03e61a6af4931073bd32daed344147c`.
Native `snapshot.py` SHA-256 `3a013e25b287b1776853b523de5475edd41e0b0395bd688be270daffed0250ff`.
Native `proposed-argv.json` SHA-256 `f9b67fe9f09bdf1cf518a720b55de9b4fe61aa49a3dabf25df4324c05a01968e`.
Native `expected-inputs.sha256` SHA-256 `e42ad7adc5a5098523509a667ff4b7bbc1c082e8547ac6de196b3cc5c7965880`.
Native `bundle.sha256` SHA-256 `4bd2f40a2e1a4b57033f413469bdf834b588ec725a8a5f37be547fbf2a34e61b`.
Native `proposed-command.sh` SHA-256 `89867d29c785cbeb981573d864d112a85a678b3b8d15270062fdff382592c548`.
Native `proposed-daemon-command.sh` SHA-256 `1b283d5de2a955f57b11f97fb38aa52e4b902d7e175000ed055a0ecf2b1903ce`.

Poteto Feature/Investigation/pickup and split-PR workflow read. Official Skill Creator replaces absent Cursor create-skill.
No nested worker/model call or unavailable Cursor role claimed; root independent review remains required.
Laziness Protocol kept only NONCE; Model the Domain retained literal argv; Prove It Works restricted evidence to inspected bytes.
Deslop found no extra comments, abstractions or unrelated edits. No Comments nested review deferred under explicit no-nested-worker scope.
Commit identity used command-local prior repository identity after Git reported missing identity; no Git config changed.
Source and preparation were committed and pushed. No PR or merge before independently accepted proof.
Full make verify remains mandatory before product Go review; later component targets codex/goal330-substrate-integration-20261020 then Vespiary pin and aggregate 493.
Requested next gate is exact offline source/controller review and separate root grant only. Ownership remains retained; native grant is not requested yet.
