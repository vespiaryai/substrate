# Certificate validation source checkpoint

This owner explicitly inherits all twelve updated standing orders in `/home/zack/.codex/orchestrate/vespiary-goal330/preferences.md`.
The source is `4e0fdbaf21db818706fdf67b3e56201d34dfd433` on `vespiary-ai/goal330-substrate-cert-validation`.
The observed origin fetch and push URL is `git@github.com:vespiaryai/substrate.git`.
Future pushes must name that fork explicitly after another remote check.
Root owns all GitHub publication, independent reviews, integration, and Vespiary pin or bundle work.

## Prepared regression

`cmd/ate-setup/internal/cmd/certificate_validation_test.go` uses the actual Cobra root and its unchanged `PersistentPreRunE`.
Only the selected leaf `RunE` becomes a distinct sentinel error.
The fixture supplies a native kubeconfig, explicit context, node and cluster UIDs, kubelet root, size0, and Envoy, with all S3 settings absent.
It restores command structs, flag values and Changed bits, registered environment values, package globals, and log output.
The sentinel prevents the installer body and success-record hook from running.

The intended baseline result is three failing certificate cases with the literal existing S3 refusal and zero HTTP requests.
A storage-command control must pass by requiring that same refusal before requests.
A valid-S3 native fixture control must reach its sentinel through the same real root and required GETs on unchanged production.
After the repair, certificate cases require the sentinel and exactly the namespace, node, and certificate-discovery GETs.
The fixture represents retained PV and PVC data, but the allowed request list excludes storage reads and every mutation.
No test, formatter, Go command, build, installer, live command, or verification script has run.
Compilation and regression red remain unproved.

## Bounded execution request

Filesystem inspection found `go 1.27.0` in `go.mod`, no source mise file, and only mise Go `1.27.2` installed.
The global mise file declares only Node `latest`.
No tool version has been executed or claimed verified.
Root follow-up `msg_4da3c0d03150` interprets the module directive as a minimum and directs use of installed mise Go 1.27.2 without installing 1.27.0.
There is no toolchain directive. The recorded execution version must be 1.27.2 under that instruction.
The requested next slot is prerequisite setup and baseline red only, after accepted-spec and P1a proof work.

1. Enter the coordinator-granted heavy slot and use `/tmp/vespiary-heavy-validation.lock` without polling or bypass.
2. Select existing mise Go `1.27.2` explicitly without a tool install or tracked configuration change.
3. Record actual `mise exec go@1.27.2 -- go version` and resolved executable path. Record any later necessary installation changes and reversal separately.
4. Run in a task-named user unit with `CPUQuota=200%`, `MemoryMax=4G`, `MemorySwapMax=0`, bounded runtime, `GOMAXPROCS=2`, and `GOFLAGS=-p=2`.
5. Use task-owned Go build and module caches. Set `GOTOOLCHAIN=local` so execution cannot silently select another Go version.
6. Reuse the unchanged reviewed `source-guard.py` archived in Vespiary source `910533954aba8c36cdbba9569c16e5973e64ff7e`, at `docs/wayfinder/effect-evidence/pilot-helm-fixture-20261020/receipts.tar.gz`. Extract only that member outside the source tree. Require SHA256 `f98fc81cd69683177d44492150f68eec36bef531fe496a5bcd5cdc90979a9296` before execution. Freeze all writers and capture actual source, tests, configuration, and new test-oracle bytes before and after every command, including untracked inputs. Bind each manifest to committed bytes or preserve those bytes. Keep receipts outside source until the command finishes.
7. Prove the byte guard refuses a deliberate source mutation in an owned disposable fixture before accepting verification receipts.
8. Run only the three prepared tests first, with a bounded test timeout, preserving the complete receipt and exit status.
9. Require exact S3-error assertion failures and zero requests for all three certificate spellings. Compilation failure is not red proof.
10. Return the slot and report the result before editing production code or requesting the later validation slot.

No sudo or host security change is currently needed or attempted.
If unit controls, the selected installed Go, or any prerequisite fails, preserve the exact failed gate and stop dependent work.
Do not relax limits, auto-download another toolchain, or change source pins.

## Remaining source unit

Root selected candidate B with the exact judge corrections in the full store synthesis.
The data shape is ephemeral `ValidationPurpose uint8`, strict zero, one certificate value, and strict unknown values.
The one command allowlist uses canonical resolved runnable ancestry and passes a local purpose through loading and preflight.
Config, Env, settings, flags, records, and reports retain no authority.
Strict guards belong at apiserver, atelet, API environment, shared demo deployment, and benchmark entry points.
Whole-system preserves its preliminary option error order and strict preflight even with CSI none.
Direct CSI none keeps its no-op after driver validation.
`EnsureCRDs` gains no storage policy.

All synthesis obligations remain pending beyond this initial prepared regression.
They include every operational leaf and alias, future and lookalike commands, unknown enum values, common config and runtime identity cases, per-field S3 failures, strict positive controls, actual precedence and record replay, direct reuse guards, and existing CSI and CA behavior.
The later slot must run focused config, cmd, steps, and demos tests, then mandatory `make verify`.
The recovered target runs `go test -race ./...` and all fourteen `hack/verify/*.sh` scripts through `hack/verify-all.sh`.
Those scripts may install or execute Go tools, Python license tooling, code generators, ShellCheck, and Weaver or pinned containers.
Every such prerequisite and execution stays inside the one heavy slot and the byte guard.
Missing prerequisites leave the source unit pending without a waiver.

## Workflow receipt

Poteto Bug fix steps are the active checklist.

- [ ] Reproduce it yourself on the matching surface via the control skill.
- [ ] Binary-search the cause.
- [ ] Plan the fix.
- [ ] Verify on the same surface.
- [ ] Stage the commits so the failing repro lands before the fix in git history.
- [ ] Run Opening a PR.

The first step awaits the execution slot. Root supplied original How grounding, distinct Architect candidates, independent judgment, and synthesis.
No additional worker or substitute Cursor Task role ran here.
Official installed skill-creator supplies agent-facing prose guidance instead of absent Cursor-only create-skill.
Root will dispatch original Comment Sicko and fresh local Sol source review before integration.
The split workflow keeps this external source repair separate from accepted-spec and Vespiary source-pin work.

Model the Domain keeps purpose typed and ephemeral.
Boundary Discipline keeps command authority at the real Cobra boundary and reuse guards at actual mutating entrances.
Test Behavior, Not Implementation requires literal errors, sentinel reachability, and actual HTTP observations.
Sequence Work into Verifiable Units keeps production unchanged until baseline red is proved.
Prove It Works prevents claiming an unexecuted test or any runtime qualification.

Throughput checkpoint is source inspection and regression preparation only, with execution deliberately queued.
No commit, push, PR, runtime profile selection, infrastructure mutation, or Goal 330 completion is claimed.
Root replied to the slot request that this owner stays active. The slot remains queued after accepted-spec catalog and P1a oracle or type replay, with no setup or tests until an explicit grant after positive release.
