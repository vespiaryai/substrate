import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path.cwd()
prefix = Path(sys.argv[1])

def snapshot():
    names = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard']).decode().split('\0')
    rows = {}
    for name in sorted(set(names)):
        if not name or name.startswith('docs/wayfinder/effect-evidence/pilot-helm-fixture-20261020/'):
            continue
        path = root / name
        if not path.is_file():
            rows[name] = None
            continue
        content = path.read_bytes()
        rows[name] = {'sha256': hashlib.sha256(content).hexdigest(), 'bytes': len(content)}
    return rows

before = snapshot()
prefix.with_suffix('.before.json').write_text(json.dumps(before, indent=2) + '\n')
result = subprocess.run(sys.argv[2:])
after = snapshot()
prefix.with_suffix('.after.json').write_text(json.dumps(after, indent=2) + '\n')
changed = [name for name in sorted(before.keys() | after.keys()) if before.get(name) != after.get(name)]
receipt = {'command': sys.argv[2:], 'command_exit': result.returncode, 'files': len(before), 'changed': changed, 'stable': not changed}
prefix.with_suffix('.guard.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
raise SystemExit(result.returncode if not changed else 97)
