#!/usr/bin/bash
set -euo pipefail
base=/tmp/goal330-substrate-cert-validation-ctx_dec0793520d9
source=/home/zack/orca/workspaces/substrate-goal330-20261020/goal330-substrate-cert-validation
round="$1"
unit="$2"
receipts="$base/focused-$round"
mkdir -p "$receipts"
export GOTOOLCHAIN=local GOMAXPROCS=2 GOFLAGS=-p=2 GOPROXY=off GOSUMDB=sum.golang.org
export GOCACHE="$base/cache/build" GOMODCACHE="$base/cache/modules" GOPATH="$base/cache/gopath"
cd "$source"
systemctl --user show "$unit" -p ActiveState -p SubState -p MainPID -p CPUQuotaPerSecUSec -p MemoryMax -p MemorySwapMax -p RuntimeMaxUSec > "$receipts/unit-during.txt"
cat "$receipts/unit-during.txt"
sha256sum "$base/tools/source-guard.py" > "$receipts/guard-before.sha256"
git rev-parse HEAD > "$receipts/source-head.txt"
git diff --binary HEAD > "$receipts/tracked-before.patch"
python3 - "$receipts" <<'INPUTS'
from pathlib import Path
import subprocess, sys
out=Path(sys.argv[1])/'changed-inputs'
names=set()
for args in [['git','diff','--name-only','-z','HEAD'],['git','ls-files','--others','--exclude-standard','-z']]:
    names.update(subprocess.check_output(args).decode().split('\0'))
for name in names:
    if name:
        target=out/name
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(Path(name).read_bytes())
INPUTS
set +e
python3 "$base/tools/source-guard.py" "$receipts/focused" /home/zack/.local/bin/mise exec go@1.27.2 -- go test -p=2 -count=1 -timeout=120s ./cmd/ate-setup/internal/config ./cmd/ate-setup/internal/cmd ./cmd/ate-setup/internal/steps ./cmd/ate-setup/internal/demos/... > "$receipts/focused.log" 2>&1
result=$?
set -e
printf '%s\n' "$result" > "$receipts/focused.exit"
cat "$receipts/focused.log"
sha256sum "$base/tools/source-guard.py" > "$receipts/guard-after.sha256"
cmp "$receipts/guard-before.sha256" "$receipts/guard-after.sha256"
exit "$result"
